<?php
include('header.php');

if(!isset($_SESSION['id'])){

echo "<script>window.location.href='index.php?needlog=You need to Login first'</script>";

}

?>
		<!--end: Container-->
				
		<!--start: Container -->
    	<div class="container">
         <form>
          <div  class="form-group">
           <div class="row">
	        <div class="span2">
               
             <select style="width:100%;">

  <option>Girls</option>
  <option>Girls and Ladyboys</option>
  <option >Ladyboys</option>
  <option >Guys</option>
   <option>Girls</option>
</select>
            </div>
            <div class="span2">
              
                   <select style="width:100%;">
  <option>Age</option>
  <option>18 Years</option>
  <option >20 Years</option>
  <option >24 Years</option>
  <option >30 Years</option>
</select>
            </div>
            <div class="span2">

                   <select style="width:100%;">
  <option> Ignore their age range</option>
  <option>Respect their age range</option>
  
</select>
            
             
            </div>
             <div class="span2">

                   <select style="width:100%;">
  <option> Height</option>
  <option>5'2"</option>
  <option>5'3"</option>
  <option>5'4"</option>
  <option>5'8"</option>
</select>
            
             
            </div>
              <div class="span2">

                   <select style="width:100%;">
  <option>Weight</option>
  <option>50 kg</option>
  <option>55 kg</option>
  <option>45 kg</option>
  <option>52 kg</option>
</select>
            
             
            </div>
             <div class="span2">

                   <select style="width:100%;">
  <option>Status</option>
  <option>Single</option>
  <option>Married</option>
 
</select>
            
             
            </div>
               <div class="span2">

                   <select style="width:100%;">
  <option>Any Eduction</option>
   <option>No Education</option>
  <option>High School </option>
  <option>College </option>
  <option>Bachelers Degree</option>
   <option>Masters Degree</option>
 
</select>
            
             
            </div>
               <div class="span2">

                   <select style="width:100%;">
  <option>Any Children</option>
  <option>No Children</option>
  <option>Has Children</option>
 
</select>
</div>
  <div class="span2">

                   <select style="width:100%;">
  <option>Face Feature</option>
  <option>fair</option>
  <option>Dark</option>
 
</select>
   </div>
     <div class="span2">

                   <select style="width:100%;">
  <option>Hair</option>
  <option>Black</option>
  <option>Golden Brown</option>
 
</select>
   </div>
             <div class="span2">

              <input type="submit" value="Search" class="btn btn-success btn-large"/>
            
             
            </div>
             <div class="span1">

              <input type="checkbox"/><label>Online</label>
            
             
            </div>
             <div class="span1">

              <input type="checkbox"/><label>Photo</label>
            
             
            </div>

           
           </div>
          </div>
         </form>
			
  
      	
            <div class="row">
           <div class="span4" style="float:right;">
              <select style="width:100%;">
  <option>Order by Last Active</option>
  <option>Order by Last Login</option>
  <option>Order by Join Date</option>
 
</select>
           </div>
         </div>
      		<!-- start: Row -->
      		<div class="row">
          		<?php
				$users= mysql_query("select * from user_register");
				while($fetchuser= mysql_fetch_array($users))
				{
						$dateOfBirth = $fetchuser['dob'];
			$today = date("Y-m-d");
			$diff = date_diff(date_create($dateOfBirth), date_create($today));
			$age= $diff->format('%y')
				?>
	           
        		<div class="span2">
                   <a href="member-single.php?user=<?php echo $fetchuser['id'];  ?>"><?php if($fetchuser['image']=='' && $fetchuser['gender']=='male') { ?> <img src="img/male.jpg" style="height: 180px;"/><?php } elseif($fetchuser['image']=='' && $fetchuser['gender']=='female'){ ?> <img src="img/girl.png" style="height: 180px;"/> <?php } else { ?> <img src="upload/dp/<?php echo $fetchuser['image'];  ?>" style="height: 180px;"/><?php } ?></a>
          			<div class="icons-box">
						
						<div class="title"><h6><?php echo $fetchuser['name']; ?></h6>
                            <h6><?php echo $age; ?></h6>
                        </div>
						

						<div class="clear"></div>
					</div>
        		</div>

        		<?php } ?>
                
				
         
      

      		</div>
			   <div class="pagination light-theme simple-pagination" style="margin-left:auto;margin-right:auto;margin-top:20px;margin-bottom:15px;"><center><ul><li class="active"><span class="current prev">Prev</span></li><li class="active"><span class="current">1</span></li><li class="active"><span class="current next">Next</span></li></ul></center></div>
			<!-- end: Row -->
      <br><br>
			
		</div>
		<!--end: Container-->
				
		<!--start: Container -->
    	<?php include("footer.php"); ?>