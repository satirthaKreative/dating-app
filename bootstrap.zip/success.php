<?php 

 $paym=$_GET['succ'];
 $paysid = $_GET['sid'];

 echo $today = date('Y-m-d');

$date3 = date("Y-m-d", strtotime(" +1 months"));

$date4 = date("Y-m-d", strtotime(" +3 months"));

$date5 = date("Y-m-d", strtotime(" +6 months"));

$date6 = date("Y-m-d", strtotime(" +12 months"));

 if($paym=24.95){
 $paysql = mysql_query("insert into membership set  usid='".$paysid."' , startdate = '".date('Y-m-d')."' , endate ='".$date3."', money = '".$paym."' ");
}elseif($paym=49.95){
  $paysql = mysql_query("insert into membership set  usid='".$paysid."' , startdate = '".date('Y-m-d')."' , endate ='".$date4."', money = '".$paym."' ");
}elseif($paym=69.95){
   $paysql = mysql_query("insert into membership set  usid='".$paysid."' , startdate = '".date('Y-m-d')."' , endate ='".$date5."', money = '".$paym."' ");
}elseif($paym=99.95){
   $paysql = mysql_query("insert into membership set  usid='".$paysid."' , startdate = '".date('Y-m-d')."' , endate ='".$date6."',money = '".$paym."' ");
}else{

}



 ?>