<?php
session_start();

mysql_select_db("datingnew",mysql_connect("localhost","saikat_dating","saikat007@"));
?>